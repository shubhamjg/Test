package com.example.walmartasessment.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import androidx.fragment.app.activityViewModels
import com.example.walmartasessment.R
import com.example.walmartasessment.databinding.FragmentCountryBinding
import com.example.walmartasessment.viewmodel.CountryCapitalViewModel


class CountryFragment : Fragment() {

    lateinit var binding: FragmentCountryBinding
    val viewModel: CountryCapitalViewModel by activityViewModels {
        CountryCapitalViewModel.factory
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCountryBinding.inflate(inflater,container,false)
        setupObserver()
        return binding.root
    }

    lateinit var countries: List<String>

    fun setupObserver(){
        viewModel.countries.observe(viewLifecycleOwner){
            countries = it.keys.toList()
            val adapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_item,
                android.R.id.text1,
                it.keys.toList()
            )

            binding.spinnerCountry.adapter = adapter

            binding.spinnerCountry.onItemSelectedListener = object : OnItemSelectedListener{
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    viewModel.setCountry(countries[position])
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    TODO("Not yet implemented")
                }

            }
        }
    }

}