package com.example.walmartasessment.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.walmartasessment.databinding.FragmentCapitalBinding
import com.example.walmartasessment.viewmodel.CountryCapitalViewModel


class CapitalFragment : Fragment() {

    lateinit var binding: FragmentCapitalBinding
    val viewModel: CountryCapitalViewModel by activityViewModels {
        CountryCapitalViewModel.factory
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCapitalBinding.inflate(inflater,container,false)
        setupObservers()
        return binding.root
    }

    fun setupObservers(){
        viewModel.capital.observe(viewLifecycleOwner){
            binding.textCapital.text = it ?: "NA"
        }
    }
}