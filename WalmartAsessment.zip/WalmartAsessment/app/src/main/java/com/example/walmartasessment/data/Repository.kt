package com.example.walmartasessment.data

class Repository {

    fun getCountries()= mutableMapOf<String,String>().apply {
        put("Select Country", "")
        put("India","Delhi")
        put("UK","London")
        put("USA","Washington D.C")
    }
}