package com.example.walmartasessment.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.walmartasessment.data.Repository

class CountryCapitalViewModel(private val repository: Repository):ViewModel() {

    val countries = MutableLiveData<MutableMap<String,String>>()

    fun loadCountries(){
        countries.postValue(repository.getCountries())
    }

    val selectedCountry = MutableLiveData<String>()
    val capital = MutableLiveData<String>()

    fun setCountry(country:String){
        selectedCountry.postValue(country)
        capital.postValue(countries.value?.get(country))
    }

    companion object{
        val factory = object :ViewModelProvider.NewInstanceFactory(){
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return CountryCapitalViewModel(Repository()) as T
            }
        }
    }
}