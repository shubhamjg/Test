package com.example.walmartasessment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.fragment.app.activityViewModels
import com.example.walmartasessment.databinding.ActivityMainBinding
import com.example.walmartasessment.view.CapitalFragment
import com.example.walmartasessment.view.CountryFragment
import com.example.walmartasessment.viewmodel.CountryCapitalViewModel

class MainActivity : AppCompatActivity() {

    val viewModel: CountryCapitalViewModel by viewModels {
        CountryCapitalViewModel.factory
    }

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        supportFragmentManager.beginTransaction().add(R.id.country_container,CountryFragment()).commit()
        supportFragmentManager.beginTransaction().add(R.id.capital_container, CapitalFragment()).commit()
        viewModel.loadCountries()
        setContentView(binding.root)
    }
}