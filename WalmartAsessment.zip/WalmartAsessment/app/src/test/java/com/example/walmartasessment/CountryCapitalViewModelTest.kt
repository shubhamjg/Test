package com.example.walmartasessment

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.Observer
import com.example.walmartasessment.data.Repository
import com.example.walmartasessment.viewmodel.CountryCapitalViewModel
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner
import org.mockito.kotlin.verify


@RunWith(MockitoJUnitRunner::class)
class CountryCapitalViewModelTest {

    @get:Rule
    val rule = InstantTaskExecutorRule()

    @Mock
    lateinit var capitalObserver: Observer<String>

    @Test
    fun selectionRepository(){
        val viewModel = CountryCapitalViewModel(Repository())
        viewModel.loadCountries()
        viewModel.capital.observeForever(capitalObserver)
        viewModel.setCountry("India")
        verify(capitalObserver).onChanged("Delhi")
        viewModel.capital.removeObserver(capitalObserver)
    }

//    @Test
//    fun TestIfNoCountryPresent(){
//        val viewModel = CountryCapitalViewModel(Repository())
//        viewModel.loadCountries()
//        viewModel.capital.observeForever(capitalObserver)
//        viewModel.setCountry("AIndia")
//        verify(capitalObserver).onChanged("")
//        viewModel.capital.removeObserver(capitalObserver)
//    }
}